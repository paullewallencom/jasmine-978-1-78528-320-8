# Jasmine Testing Example [![Build Status](https://secure.travis-ci.org/pirelenito/jasmine-testing-example.png)](https://travis-ci.org/pirelenito/jasmine-testing-example)

This is an example project tested using Jasmine. Still work in progress.