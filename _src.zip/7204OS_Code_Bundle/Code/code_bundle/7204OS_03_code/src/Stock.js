(function () {
  function Stock (params) {
    var params = params || {};
    this.symbol = params.symbol;
  };

  this.Stock = Stock;
})();