require([
  'Application'
],
function (Application) {
  Application.start();
});