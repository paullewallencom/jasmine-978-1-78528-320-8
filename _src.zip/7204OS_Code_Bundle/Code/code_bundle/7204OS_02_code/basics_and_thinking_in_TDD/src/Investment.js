function Investment (stock) {
  this.stock = stock;
}
