function Stock (options) {
}
